# Sylvester Keaton Clarke — Portfolio Site

A single-page executive portfolio built with plain HTML/CSS (no build step, no dependencies besides Google Fonts).

## Deploy to GitHub Pages (free, ~5 minutes)

1. **Create a new repository** on GitHub:
   - Go to https://github.com/new
   - Name it exactly `your-username.github.io` (replace `your-username` with your actual GitHub username) — this special name makes GitHub host it at the root of that URL automatically.
   - Set it to **Public**, then click **Create repository**.

2. **Upload the file:**
   - On the new repo's page, click **"Add file" → "Upload files"**.
   - Drag in `index.html` from this folder.
   - Scroll down and click **"Commit changes"**.

3. **Turn on GitHub Pages:**
   - Go to the repo's **Settings** tab → **Pages** (left sidebar).
   - Under "Build and deployment", set **Source** to **Deploy from a branch**, branch **main**, folder **/(root)**.
   - Click **Save**.

4. **Wait ~1 minute**, then your site is live at:
   `https://your-username.github.io`

   If you'd rather not use the special `username.github.io` repo name, you can name the repo anything (e.g. `portfolio`) — it will instead be hosted at `https://your-username.github.io/portfolio`.

## Sharing with recruiters

Once live, share the link directly (e.g. `https://your-username.github.io`) — this is the link to put on your resume, LinkedIn, and cover letters instead of `capt-keaton.github.io` if you set up a new repo under a different username or path.

## Editing later

The entire site is one file, `index.html`. To make a change:
- Edit it directly in GitHub (open the file in your repo, click the pencil icon, edit, commit).
- Or edit locally and re-upload.
