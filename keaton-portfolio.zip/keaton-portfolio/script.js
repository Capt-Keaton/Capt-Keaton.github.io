document.getElementById('year').textContent = new Date().getFullYear();

// Mobile nav toggle
const header = document.getElementById('siteHeader');
const navToggle = document.getElementById('navToggle');
if (navToggle) {
  navToggle.addEventListener('click', () => {
    const isOpen = header.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });
  document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
      header.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    });
  });
}

// Departure board: single orchestrated reveal when it scrolls into view
const board = document.getElementById('skillsBoard');
if (board && 'IntersectionObserver' in window) {
  const flaps = board.querySelectorAll('.flap');
  flaps.forEach((flap, i) => {
    flap.style.transitionDelay = `${Math.min(i * 45, 500)}ms`;
  });
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        board.classList.add('is-visible');
        observer.disconnect();
      }
    });
  }, { threshold: 0.25 });
  observer.observe(board);
} else if (board) {
  board.classList.add('is-visible');
}
