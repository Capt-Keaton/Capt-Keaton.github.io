# Sylvester Keaton Clarke — Portfolio

An aviation-themed personal portfolio site: boarding-pass hero, a "flight path" work
history timeline, and a departure-board skills section. Pure HTML/CSS/JS — no build
step, no dependencies to install.

## Files
- `index.html` — the page
- `styles.css` — all styling
- `script.js` — mobile nav + the departure-board reveal animation
- `assets/Sylvester-Keaton-Clarke-Resume.pdf` — downloadable CV (linked from the "Download CV" button)

## View it locally
Just open `index.html` in a browser — everything is self-contained except Google Fonts,
which load from the internet.

## Publish it for free with GitHub Pages
1. Go to [github.com/new](https://github.com/new) and create a repository — name it
   whatever you like, e.g. `keaton-portfolio`. Keep it **Public** (Pages needs that on
   a free account) and don't add a README/gitignore (this folder already has one).
2. On your computer/phone, upload these files into that new repository. The easiest way
   without using the command line:
   - Open the repo on GitHub → **Add file → Upload files**
   - Drag in `index.html`, `styles.css`, `script.js`, `README.md`, and the `assets`
     folder (with the PDF inside it)
   - Commit the upload
3. In the repo, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source** to **Deploy from a branch**, branch
   **main**, folder **/ (root)** → **Save**.
5. GitHub gives you a live link, usually:
   `https://<your-github-username>.github.io/<repo-name>/`
   It can take a minute or two to go live the first time.

Send that link to recruiters — that's the one to put on your CV and LinkedIn.

## If you'd rather use git from the command line
```bash
cd keaton-portfolio        # the folder with these files
git init
git add .
git commit -m "Launch portfolio"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
Then follow steps 3–4 above to switch on Pages.

## Updating later
Any time you edit `index.html` (new job, new certification, updated numbers), upload
the changed file again through **Add file → Upload files** and commit — GitHub Pages
rebuilds automatically within a minute or two.
